package com.hytcshare.jerrywebspider;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JerryWebSpiderApplication {

    public static void main(String[] args) {
        SpringApplication.run(JerryWebSpiderApplication.class, args);
    }
}
