package com.hytcshare.jerrywebspider.dao;

import com.hytcshare.jerrywebspider.entity.TuwanMp3;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TuwanMp3Dao extends JpaRepository<TuwanMp3, Integer> {
}
