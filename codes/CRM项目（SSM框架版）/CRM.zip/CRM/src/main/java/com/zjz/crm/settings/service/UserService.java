package com.zjz.crm.settings.service;

import com.zjz.crm.settings.web.controller.domain.User;

import java.util.List;
import java.util.Map;

public interface UserService {
    User queryUserByLoginActAndPwd(Map<String,Object> map);

    List<User> queryAllUsers();
}
