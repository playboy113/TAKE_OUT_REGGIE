package com.hytcshare.jerrywebspider.constant;

public class TuwanConstant {
    public static String THUMB_PREFIX = "http://img4.tuwandata.com/v3/thumb/jpg/";
    public static int THUMB_PARTITION_MIN_LENGTH = 9;
    public static int THUMB_CODE_POSITION = 6;
    public static String THUMB_CODE_SEPARATOR = ",";
    public static int THUMB_CODE_PARTITION_MIN_LENGTH = 11;
    public static String MAHOU_CODE = ",0,0,9,3,1,-1,NONE,,,90";
}
